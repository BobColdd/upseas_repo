"""Flask backend: PostgreSQL logins, protected pages, and JSON/audio content from Cloudflare R2."""
import hmac
import json
import os
import re
import secrets
import time
from datetime import datetime, timezone
from functools import wraps
from pathlib import Path

import psycopg
from dotenv import load_dotenv
from psycopg.rows import dict_row
from psycopg.types.json import Jsonb
from psycopg_pool import ConnectionPool
from flask import Flask, Response, abort, jsonify, redirect, request, send_from_directory, session

load_dotenv()

BASE = Path(__file__).resolve().parent
PUBLIC_DIR = BASE / "public"                      # html, css, js
LOCAL_DIR = BASE / os.environ.get("LOCAL_CONTENT_DIR", "content")  # used only when R2 is not configured
CACHE_SECONDS = int(os.environ.get("CACHE_SECONDS", "60"))
MAX_JSON_BYTES = 1_000_000
STATE_KEY = "data/admin-data.json"  # students, tasks and mocks saved by the admin page
# Kept out of the admin's Content tab: students' answers (read them from the Students tab) and the admin's own state file.
HIDDEN_PREFIXES = ("submissions/",)
HIDDEN_KEYS = {STATE_KEY}


def cms_listed(key):
    """Only editable JSON content is listed: no audio, no submissions, no internal state."""
    return key.endswith(".json") and not key.startswith(HIDDEN_PREFIXES) and key not in HIDDEN_KEYS

app = Flask(__name__, static_folder=None)
app.secret_key = os.environ.get("SECRET_KEY") or secrets.token_hex(32)  # set SECRET_KEY, or sessions reset on restart
if not os.environ.get("SECRET_KEY"):
    print("WARNING: SECRET_KEY is not set. With more than one worker, students will be logged out at random.", flush=True)
app.config.update(
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_SECURE=os.environ.get("COOKIE_SECURE") == "1",  # set COOKIE_SECURE=1 behind HTTPS
    PERMANENT_SESSION_LIFETIME=8 * 3600,
)

# ---------------------------------------------------------------- database (PostgreSQL)
# Create it once with schema.sql, then set DATABASE_URL, e.g. postgresql://user:pass@localhost:5432/coldschool
DATABASE_URL = os.environ.get("DATABASE_URL")
if not DATABASE_URL:
    raise RuntimeError("DATABASE_URL is not set (see .env.example)")
pool = ConnectionPool(DATABASE_URL, min_size=1, max_size=int(os.environ.get("DB_POOL_MAX", "5")),
                      kwargs={"row_factory": dict_row}, open=False)
pool.open()

EMAIL_RE = re.compile(r"^\S+@\S+\.\S+$")
ID_RE = re.compile(r"^STD[\s/_-]*(\d{1,9})$", re.I)   # how a student may type their ID: STD/001, std 001, STD-1, std001


def clean_login(text):
    """An email stays as typed; anything that looks like a student ID becomes STD/001."""
    m = ID_RE.match(text.strip())
    return f"STD/{int(m.group(1)):03d}" if m else text
# Skill folders in the bucket (reading/reading-passages.json, listening/..., and so on)
CONTENT_FOLDERS = ("reading", "listening", "writing", "speaking")

# page -> who may open it (None = public)
PAGES = {"index.html": None, "login.html": None, "notes.html": "user", "dashboard.html": "student",
         "practice.html": "student", "admin.html": "admin"}
LEGACY_PAGES = {"quiz.html": "practice.html"}   # old bookmarks / ?next= links keep working

# ---------------------------------------------------------------- storage (R2 or local folder)
R2_OK = all(os.environ.get(k) for k in ("R2_ACCOUNT_ID", "R2_ACCESS_KEY_ID", "R2_SECRET_ACCESS_KEY", "R2_BUCKET"))
PREFIX = os.environ.get("R2_KEY_PREFIX", "")      # optional folder inside the bucket, e.g. "upseas/"
if R2_OK:
    import boto3
    from botocore.config import Config
    from botocore.exceptions import ClientError

    BUCKET = os.environ["R2_BUCKET"]
    s3 = boto3.client(
        "s3",
        endpoint_url=f"https://{os.environ['R2_ACCOUNT_ID']}.r2.cloudflarestorage.com",
        aws_access_key_id=os.environ["R2_ACCESS_KEY_ID"],
        aws_secret_access_key=os.environ["R2_SECRET_ACCESS_KEY"],
        region_name="auto",
        config=Config(signature_version="s3v4"),
    )

KEY_RE = re.compile(r"^[A-Za-z0-9_\-./() ]{1,200}$")


def valid_key(key):
    return bool(KEY_RE.match(key)) and ".." not in key and not key.startswith("/")


def _local_path(key):
    p = (LOCAL_DIR / key).resolve()
    return p if LOCAL_DIR.resolve() in p.parents else None


def store_list():
    out = []
    if R2_OK:
        token = None
        while True:
            kw = {"Bucket": BUCKET, "Prefix": PREFIX, "MaxKeys": 1000}
            if token:
                kw["ContinuationToken"] = token
            r = s3.list_objects_v2(**kw)
            for o in r.get("Contents", []):
                k = o["Key"][len(PREFIX):]
                if k and not k.endswith("/"):
                    out.append({"key": k, "size": o["Size"], "modified": o["LastModified"].isoformat()})
            if not r.get("IsTruncated"):
                break
            token = r["NextContinuationToken"]
        return out
    if LOCAL_DIR.exists():
        for p in LOCAL_DIR.rglob("*"):
            if p.is_file():
                st = p.stat()
                out.append({
                    "key": p.relative_to(LOCAL_DIR).as_posix(),
                    "size": st.st_size,
                    "modified": datetime.fromtimestamp(st.st_mtime, timezone.utc).isoformat(),
                })
    return out


def store_get(key):
    if R2_OK:
        try:
            return s3.get_object(Bucket=BUCKET, Key=PREFIX + key)["Body"].read()
        except ClientError as e:
            if e.response["Error"]["Code"] in ("NoSuchKey", "404", "NotFound"):
                return None
            raise
    p = _local_path(key)
    return p.read_bytes() if p and p.is_file() else None


def store_put(key, data):
    if R2_OK:
        s3.put_object(Bucket=BUCKET, Key=PREFIX + key, Body=data, ContentType="application/json")
        return
    p = _local_path(key)
    if not p:
        abort(400)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(data)


CACHE = {}  # per-process; each worker keeps its own copy


def cached_get(key):
    hit = CACHE.get(key)
    if hit and time.time() - hit[0] < CACHE_SECONDS:
        return hit[1]
    data = store_get(key)
    if data is not None:
        CACHE[key] = (time.time(), data)
    return data


DIR_CACHE = {}  # folder -> (loaded at, [keys]) ; per worker, 15 s


def store_dir_keys(folder):
    """Keys directly inside one folder of the bucket."""
    hit = DIR_CACHE.get(folder)
    if hit and time.time() - hit[0] < 15:
        return hit[1]
    keys = []
    if R2_OK:
        token = None
        while True:
            kw = {"Bucket": BUCKET, "Prefix": PREFIX + folder + "/", "Delimiter": "/", "MaxKeys": 1000}
            if token:
                kw["ContinuationToken"] = token
            r = s3.list_objects_v2(**kw)
            for o in r.get("Contents", []):
                k = o["Key"][len(PREFIX):]
                if k and not k.endswith("/"):
                    keys.append(k)
            if not r.get("IsTruncated"):
                break
            token = r["NextContinuationToken"]
    else:
        d = _local_path(folder)
        if d and d.is_dir():
            keys = [p.relative_to(LOCAL_DIR).as_posix() for p in d.iterdir() if p.is_file()]
    DIR_CACHE[folder] = (time.time(), keys)
    return keys


def resolve_key(key):
    """R2 keys are case-sensitive: find Questions.json when the code asks for questions.json (same folder, any capitalisation of the file name)."""
    folder, _, base = key.rpartition("/")
    if not folder:
        return key
    keys = store_dir_keys(folder)
    if key in keys:
        return key
    return next((k for k in keys if k.rsplit("/", 1)[-1].lower() == base.lower()), None)


# ---------------------------------------------------------------- answer keys and marking
# One JSON per test holds passages/sections, questions AND answers, e.g. reading/reading-19-test1.json:
#   {"layout":"reading","time":3600,"passages":[{"id":"p1","label":"Passage 1","title":"...","paragraphs":[...],
#     "heading":"Questions 1-5","questions":[{"id":"q1","type":"tfng","text":"...","answer":"NOT GIVEN"}, ...]}]}
# Answer keys ("answer", "accept", "explanation") are removed before a student is sent the file.
#   text : "answer": "library"  or  ["colour","color"]      mcq : "answer": "B"
#   map  : "answer": "C"                                    tfng: "answer": "TRUE" | "FALSE" | "NOT GIVEN" (YES/NO also fine)
ANSWER_KEYS = {"answer", "accept", "explanation"}
SECTION_LISTS = ("passages", "sections", "tasks", "parts")
TFNG = {"true": "true", "yes": "true", "false": "false", "no": "false", "not given": "not given", "ng": "not given"}
BAND_TABLES = {   # 40-question tests only (Academic Reading, Listening)
    "reading":   [(39, 9), (37, 8.5), (35, 8), (33, 7.5), (30, 7), (27, 6.5), (23, 6), (19, 5.5), (15, 5), (13, 4.5), (10, 4)],
    "listening": [(39, 9), (37, 8.5), (35, 8), (32, 7.5), (30, 7), (26, 6.5), (23, 6), (18, 5.5), (16, 5), (13, 4.5), (10, 4)],
}


def strip_answers(node):
    if isinstance(node, dict):
        return {k: strip_answers(v) for k, v in node.items() if k not in ANSWER_KEYS}
    if isinstance(node, list):
        return [strip_answers(v) for v in node]
    return node


def sibling(key, name):
    """A file in the same R2 folder as `key`."""
    return key.rsplit("/", 1)[0] + "/" + name if "/" in key else name


def _twin(file_key, plain, legacy_word):
    base = file_key.rsplit("/", 1)[-1]
    return sibling(file_key, re.sub("passages", legacy_word, base, flags=re.I) if re.search("passages", base, re.I) else plain)


def _found(guess):
    try:
        return resolve_key(guess) or guess
    except Exception:
        app.logger.exception("folder listing failed")
        return guess


def questions_key(file_key):
    """Folder layout: reading/passage1(19)/Passage.json -> Questions.json beside it (any capitalisation).
    Older layout: reading/x-passages.json -> reading/x-questions.json."""
    return _found(_twin(file_key, "questions.json", "questions"))


def answers_key(file_key):
    return _found(_twin(file_key, "answers.json", "answers"))


def answer_map(raw):
    """answers.json as {question id or number: answer}. Accepts {"q1": "x"}, {"answers": {...}} or [{"id": "q1", "answer": "x"}]."""
    d = json.loads(raw)
    if isinstance(d, dict) and isinstance(d.get("answers"), (dict, list)):
        d = d["answers"]
    if isinstance(d, list):
        return {str(x.get("id")): x.get("answer") for x in d if isinstance(x, dict) and "id" in x}
    if isinstance(d, dict):
        return {str(k): (v.get("answer") if isinstance(v, dict) else v) for k, v in d.items()}
    return {}


def quiz_questions(file_key):
    """The test's questions with their answer keys, in the order the exam screen numbers them.
    Questions come from the assigned file itself, or from questions.json beside it; answers from "answer" on the
    question, or from answers.json beside it."""
    raw = cached_get(file_key)
    if raw is None:
        return []
    main = json.loads(raw)
    sections = next((main[k] for k in SECTION_LISTS if isinstance(main.get(k), list)), [])
    qs = []
    if any(isinstance(s, dict) and s.get("questions") for s in sections):
        for s in sections:
            qs += s.get("questions") or []
    else:
        raw2 = cached_get(questions_key(file_key))
        sets = (json.loads(raw2).get("sets") or []) if raw2 else []
        for p in sections:
            for s in sets:
                if s.get("passage") == p.get("id"):
                    qs += s.get("questions") or []
    qs = [q for q in qs if isinstance(q, dict) and q.get("type") not in ("figure", "group")]
    if any(q.get("answer") in (None, "", []) for q in qs):
        raw3 = cached_get(answers_key(file_key))
        amap = answer_map(raw3) if raw3 else {}
        for n, q in enumerate(qs, 1):
            if q.get("answer") in (None, "", []):
                q["answer"] = amap.get(str(q.get("id")), amap.get(str(n)))
    return qs


def _norm(s):
    return re.sub(r"\s+", " ", str(s).strip().lower()).strip(" .,;:!")


def mark_answers(questions, answers, review):
    """Compare the student's answers with the keys. Returns None when the test has no answer keys."""
    shown = {i.get("id"): i.get("a", "") for sec in review if isinstance(sec, dict)
             for i in (sec.get("items") or []) if isinstance(i, dict)}
    items, right = [], 0
    for n, q in enumerate(questions, 1):
        key = q.get("answer")
        if key in (None, "", []):
            continue
        qid, typ, given = q.get("id"), q.get("type"), answers.get(q.get("id"))
        if typ == "mcq":
            exp = key if isinstance(key, int) else ord(str(key).strip().upper()[:1]) - 65
            ok = isinstance(given, int) and not isinstance(given, bool) and given == exp
            expected = chr(65 + exp) if 0 <= exp < 26 else str(key)
        elif typ == "tfng":
            g = _norm(shown.get(qid, ""))
            ok = bool(g) and TFNG.get(g, g) == TFNG.get(_norm(key), _norm(key))
            expected = str(key).upper()
        else:                                      # text, map (letter), anything else
            options = key if isinstance(key, list) else [key]
            ok = given is not None and _norm(given) in {_norm(o) for o in options}
            expected = " / ".join(str(o) for o in options)
        right += ok
        items.append({"id": qid, "n": n, "correct": bool(ok), "given": shown.get(qid) or ("" if given is None else str(given)), "expected": expected})
    return {"correct": right, "total": len(items), "items": items} if items else None


def band_for(skill, correct, total):
    if total != 40 or skill not in BAND_TABLES:
        return None
    return next((b for need, b in BAND_TABLES[skill] if correct >= need), None)


# ---------------------------------------------------------------- auth helpers
STATE_TTL = int(os.environ.get("STATE_CACHE_SECONDS", "10"))
STATE_CACHE = [0.0, None]   # [loaded at, parsed admin-data.json], per worker


def load_state():
    if STATE_CACHE[1] is not None and time.time() - STATE_CACHE[0] < STATE_TTL:
        return STATE_CACHE[1]
    raw = store_get(STATE_KEY)
    data = json.loads(raw) if raw else {}
    STATE_CACHE[0], STATE_CACHE[1] = time.time(), data
    return data


def assigned_tasks(user):
    """Tasks the admin has assigned to this user (matched by email). Never exposes other students."""
    try:
        data = load_state()
    except Exception:
        app.logger.exception("could not read admin data")
        return []
    students = data.get("students", [])
    me = (next((s for s in students if s.get("id") == user["id"]), None)
          or next((s for s in students if str(s.get("email", "")).lower() == user["email"].lower()), None))
    if not me:
        return []
    return [t for t in data.get("tasks", []) if me["id"] in t.get("assignedTo", [])]

FAILS = {}  # (ip, login) -> failure timestamps, and (ip, None) -> every failure from that IP (in memory, per worker)
LOGIN_TRIES = int(os.environ.get("LOGIN_TRIES", "5"))             # wrong passwords per account, per 5 minutes
LOGIN_TRIES_IP = int(os.environ.get("LOGIN_TRIES_IP", "150"))     # all accounts together from one IP (a classroom shares one)


def too_many(ip, who):
    now = time.time()
    for k in ((ip, who), (ip, None)):
        FAILS[k] = [t for t in FAILS.get(k, []) if now - t < 300]
    return len(FAILS[(ip, who)]) >= LOGIN_TRIES or len(FAILS[(ip, None)]) >= LOGIN_TRIES_IP


def note_fail(ip, who):
    now = time.time()
    FAILS.setdefault((ip, who), []).append(now)
    FAILS.setdefault((ip, None), []).append(now)


def landing_for(user):
    return "admin.html" if user["role"] == "admin" else "dashboard.html"


def current_user():
    return session.get("user")


def api_user(role=None):
    def deco(f):
        @wraps(f)
        def wrapper(*a, **kw):
            u = current_user()
            if not u:
                return jsonify(error="login_required"), 401
            if role and u["role"] != role:
                return jsonify(error="forbidden"), 403
            return f(*a, **kw)
        return wrapper
    return deco


@app.after_request
def headers(resp):
    resp.headers["X-Content-Type-Options"] = "nosniff"
    if request.path.startswith("/api/"):
        resp.headers["Cache-Control"] = "no-store"
    return resp


@app.post("/api/login")
def api_login():
    ip = request.headers.get("CF-Connecting-IP") or request.remote_addr or "?"
    d = request.get_json(silent=True) or {}
    login = clean_login(str(d.get("email") or d.get("login") or "").strip()[:254])   # email or student ID
    who = login.lower()
    if too_many(ip, who):
        return jsonify(error="too_many"), 429
    password = str(d.get("password", ""))
    if not login or not password or len(password) > 1024:
        return jsonify(error="invalid"), 401
    with pool.connection() as conn:
        user = conn.execute(
            "SELECT id, student_code, email::text AS email, full_name, role::text AS role "
            "FROM authenticate(%s, %s)", (login, password)).fetchone()
        if not user:  # burn the same bcrypt time so unknown accounts can't be told apart by speed
            conn.execute("SELECT crypt(%s, gen_salt('bf', 12))", (password,))
    if not user:
        note_fail(ip, who)
        return jsonify(error="invalid"), 401
    FAILS.pop((ip, who), None)                 # a correct login clears that account's earlier typos
    session.clear()
    session.permanent = True
    session["user"] = {"id": str(user["id"]), "email": user["email"], "code": user["student_code"],
                       "name": user["full_name"], "role": user["role"]}
    user = session["user"]
    nxt = str(d.get("next") or "")
    nxt = LEGACY_PAGES.get(nxt, nxt)
    ok_next = (nxt in PAGES and nxt != "login.html"
               and (PAGES[nxt] != "admin" or user["role"] == "admin")
               and (PAGES[nxt] != "student" or user["role"] == "student"))
    if not ok_next:
        nxt = landing_for(user)
    return jsonify(ok=True, name=user["name"], role=user["role"], redirect="/" + nxt)


@app.post("/api/logout")
def api_logout():
    session.clear()
    return jsonify(ok=True)


REF_RE = re.compile(r"^[A-Za-z0-9_-]{1,64}$")


def sub_key(student_id, ref):
    """Where a student's answers live in R2: submissions/<student-id>/<task-id>.json"""
    return f"submissions/{student_id}/{ref}.json"


@app.get("/api/my/tasks")
@api_user()
def api_my_tasks():
    u = current_user()
    with pool.connection() as conn:
        done = {r["task_ref"]: r["submitted_at"] for r in conn.execute(
            "SELECT task_ref, submitted_at FROM submission_status WHERE student_id = %s AND status = 'YES'",
            (u["id"],)).fetchall()}
    tasks = []
    for t in assigned_tasks(u):
        at = done.get(t.get("id"))
        tasks.append({**{k: t.get(k, "") for k in ("id", "title", "skill", "note", "file")},
                      "submitted": t.get("id") in done,
                      "submittedAt": at.isoformat() if at else None})
    return jsonify(tasks=tasks)


@app.get("/api/my/submissions/<ref>")
@api_user()
def api_my_submission(ref):
    """A student's own submitted answers (for the answer-sheet view). Correct answers are never included."""
    u = current_user()
    if not REF_RE.match(ref) or not any(str(t.get("id")) == ref for t in assigned_tasks(u)):
        return jsonify(error="forbidden"), 403
    with pool.connection() as conn:
        done = conn.execute("SELECT 1 FROM submission_status WHERE student_id = %s AND task_ref = %s AND status = 'YES'",
                            (u["id"], ref)).fetchone()
    if not done:
        return jsonify(error="not_submitted"), 404
    try:
        raw = store_get(sub_key(u["id"], ref))
    except Exception:
        app.logger.exception("storage read failed")
        return jsonify(error="storage_error"), 502
    if raw is None:
        return jsonify(error="not_found"), 404
    p = json.loads(raw)
    sc = p.get("score")
    return jsonify(task={k: (p.get("task") or {}).get(k, "") for k in ("id", "title", "skill")},
                   student={k: (p.get("student") or {}).get(k) for k in ("name", "code")},
                   submittedAt=p.get("submittedAt"), review=p.get("review") or [],
                   score={k: sc[k] for k in ("correct", "total", "band")} if sc else None)


@app.post("/api/my/submissions")
@api_user()
def api_submit():
    """Student submits all answers for one assigned task, once. Answers -> R2 (JSON), status -> DB ('YES')."""
    u = current_user()
    if request.content_length and request.content_length > 300_000:
        return jsonify(error="too_large"), 413
    d = request.get_json(silent=True) or {}
    ref = str(d.get("task", ""))
    task = next((t for t in assigned_tasks(u) if str(t.get("id")) == ref), None)
    if not task or not REF_RE.match(ref):          # not assigned to this student
        return jsonify(error="forbidden"), 403
    answers, review = d.get("answers"), d.get("review")
    if not isinstance(answers, dict) or not isinstance(review, list):
        return jsonify(error="bad_payload"), 400
    secs = d.get("secondsLeft")
    secs = secs if isinstance(secs, int) and not isinstance(secs, bool) and 0 <= secs <= 86400 else None
    try:                                           # marking must never block a submission
        score = mark_answers(quiz_questions(task.get("file", "")), answers, review)
        if score:
            score["band"] = band_for(task.get("skill"), score["correct"], score["total"])
    except Exception:
        app.logger.exception("marking failed")
        score = None
    key = sub_key(u["id"], ref)
    payload = {
        "version": 1,
        "student": {"id": u["id"], "code": u.get("code"), "name": u["name"], "email": u["email"]},
        "task": {"id": ref, "title": task.get("title", ""), "skill": task.get("skill", ""), "file": task.get("file", "")},
        "submittedAt": datetime.now(timezone.utc).isoformat(),
        "secondsLeft": secs,
        "auto": bool(d.get("auto")),               # true when the timer ran out
        "answers": answers,                        # raw: {questionId: value}
        "review": review,                          # readable copy for the admin page
        "score": score,                            # None for writing/speaking or tests without answer keys
    }
    try:
        with pool.connection() as conn:
            # claim the slot first (a second click waits here, then gets 409); roll back if R2 fails
            row = conn.execute(
                "INSERT INTO submission_status (student_id, task_ref, status, r2_key, submitted_at) "
                "VALUES (%s, %s, 'YES', %s, now()) "
                "ON CONFLICT (student_id, task_ref) DO UPDATE "
                "SET status = 'YES', r2_key = EXCLUDED.r2_key, submitted_at = now() "
                "WHERE submission_status.status = 'NO' RETURNING task_ref",
                (u["id"], ref, key)).fetchone()
            if not row:
                return jsonify(error="already_submitted"), 409
            store_put(key, json.dumps(payload, ensure_ascii=False).encode("utf-8"))
    except Exception:
        app.logger.exception("submission failed")
        return jsonify(error="storage_error"), 502
    summary = {k: score[k] for k in ("correct", "total", "band")} if score else None
    return jsonify(ok=True, score=summary), 201


@app.get("/api/me")
@api_user()
def api_me():
    return jsonify(current_user())


# ---------------------------------------------------------------- content served to the site
@app.get("/data/<path:rest>")
def data_file(rest):
    key = "data/" + rest
    if not valid_key(key) or not key.endswith(".json"):
        abort(404)
    u = current_user()
    low = rest.lower()
    if "answers" in low or low.startswith("admin"):      # answers and admin data: admin only
        if not (u and u["role"] == "admin"):
            abort(403)
    elif low.startswith(("quiz/", "notes/")) and not u:  # study content: logged-in users
        abort(401)
    try:
        data = store_get(key) if low.startswith("admin") else cached_get(key)   # admin data is never cached: a stale copy would overwrite the admin's changes on the next Save
    except Exception:
        app.logger.exception("storage read failed")
        abort(502)
    if data is None:
        abort(404)
    return Response(data, mimetype="application/json", headers={"Cache-Control": "private, max-age=0, must-revalidate"})




@app.get("/content/<path:key>")
def content_file(key):
    if not valid_key(key) or not key.endswith(".json") or key.split("/")[0] not in CONTENT_FOLDERS:
        abort(404)
    u = current_user()
    if not u:
        abort(401)
    if "answers" in key.lower() and u["role"] != "admin":  # answer files: admin only
        abort(403)
    if u["role"] != "admin":                               # students: only files assigned to them
        allowed = set()
        for t in assigned_tasks(u):
            f = t.get("file") or ""
            if f:
                allowed |= {f.lower(), _twin(f, "questions.json", "questions").lower()}
        if key.lower() not in allowed:
            abort(403)
    try:
        data = cached_get(_found(key))
    except Exception:
        app.logger.exception("storage read failed")
        abort(502)
    if data is None:
        abort(404)
    if u["role"] != "admin":                               # students never receive the answer keys
        try:
            data = json.dumps(strip_answers(json.loads(data)), ensure_ascii=False).encode("utf-8")
        except ValueError:
            abort(500)
    return Response(data, mimetype="application/json", headers={"Cache-Control": "private, max-age=0, must-revalidate"})


IMAGE_TYPES = {"svg": "image/svg+xml", "png": "image/png", "jpg": "image/jpeg", "jpeg": "image/jpeg", "webp": "image/webp"}


@app.get("/images/<name>")
def quiz_image(name):
    """Maps and diagrams used in quiz questions. They live in R2 under images/ (local fallback: content/images/).
    Served through Flask so the content type is always right. Logged-in users only."""
    if not current_user():
        abort(401)
    m = re.fullmatch(r"[\w.-]+\.(svg|png|jpe?g|webp)", name, re.I)
    if not m:
        abort(404)
    try:
        data = cached_get("images/" + name)
    except Exception:
        app.logger.exception("image read failed")
        abort(502)
    if data is None:
        abort(404)
    return Response(data, mimetype=IMAGE_TYPES[m.group(1).lower()],
                    headers={"Cache-Control": "private, max-age=3600"})


@app.get("/audio/<path:rest>")
def audio_file(rest):
    key = "audio/" + rest
    if not current_user():
        abort(401)
    if not valid_key(key) or not re.search(r"\.(mp3|m4a|wav|ogg)$", key, re.I):
        abort(404)
    if R2_OK:
        url = s3.generate_presigned_url(
            "get_object", Params={"Bucket": BUCKET, "Key": PREFIX + key}, ExpiresIn=3600)
        return redirect(url, 302)
    p = _local_path(key)
    if not p or not p.is_file():
        abort(404)
    return send_from_directory(p.parent, p.name, conditional=True)


# ---------------------------------------------------------------- admin: students (PostgreSQL)
def student_json(r):
    t = r["target_band"]
    return {"id": str(r["id"]), "name": r["full_name"], "email": r["email"], "code": r["student_code"],
            "target": float(t) if t is not None else "", "assignedTo": [],
            "submitted": int(r.get("submitted") or 0)}


STUDENT_COLS = "id, student_code, email::text AS email, full_name, target_band"


@app.get("/api/admin/students")
@api_user("admin")
def admin_students():
    with pool.connection() as conn:
        rows = conn.execute(
            "SELECT u.id, u.student_code, u.email::text AS email, u.full_name, u.target_band, "
            "(SELECT count(*) FROM submission_status s WHERE s.student_id = u.id AND s.status = 'YES') AS submitted "
            "FROM users u WHERE u.role = 'student' AND u.is_active ORDER BY length(u.student_code), u.student_code").fetchall()
    return jsonify(students=[student_json(r) for r in rows])


@app.post("/api/admin/students")
@api_user("admin")
def admin_add_student():
    d = request.get_json(silent=True) or {}
    name = str(d.get("name", "")).strip()
    email = str(d.get("email", "")).strip()
    password = str(d.get("password", ""))
    try:
        target = float(d["target"]) if d.get("target") not in (None, "") else None
    except (TypeError, ValueError):
        return jsonify(error="bad_target"), 400
    if not name or len(name) > 200:
        return jsonify(error="bad_name"), 400
    if not EMAIL_RE.match(email) or len(email) > 254:
        return jsonify(error="bad_email"), 400
    if not (8 <= len(password) and len(password.encode()) <= 72):   # bcrypt only reads 72 bytes
        return jsonify(error="bad_password"), 400
    if target is not None and not (4 <= target <= 9):
        return jsonify(error="bad_target"), 400
    try:
        with pool.connection() as conn:
            new_id = conn.execute("SELECT create_student(%s::text, %s::text, %s::text, %s::numeric, %s::uuid) AS id",
                                  (email, name, password, target, current_user()["id"])).fetchone()["id"]
            row = conn.execute(f"SELECT {STUDENT_COLS} FROM users WHERE id = %s", (new_id,)).fetchone()
    except psycopg.errors.UniqueViolation:
        return jsonify(error="duplicate_email"), 409
    except psycopg.Error:
        app.logger.exception("create student failed")
        return jsonify(error="db_error"), 500
    return jsonify(ok=True, student=student_json(row)), 201


@app.post("/api/admin/students/<uuid:sid>/password")
@api_user("admin")
def admin_reset_password(sid):
    password = str((request.get_json(silent=True) or {}).get("password", ""))
    if not (8 <= len(password) and len(password.encode()) <= 72):
        return jsonify(error="bad_password"), 400
    with pool.connection() as conn:
        done = conn.execute("UPDATE users SET password_hash = crypt(%s, gen_salt('bf', 12)) "
                            "WHERE id = %s AND role = 'student' RETURNING id", (password, str(sid))).fetchone()
    return (jsonify(ok=True) if done else (jsonify(error="not_found"), 404))


@app.get("/api/admin/students/<uuid:sid>/submissions")
@api_user("admin")
def admin_student_submissions(sid):
    """Submission status per task for one student (tasks with no row are 'NO')."""
    with pool.connection() as conn:
        rows = conn.execute(
            "SELECT task_ref, status, submitted_at FROM submission_status WHERE student_id = %s "
            "ORDER BY submitted_at DESC NULLS LAST", (str(sid),)).fetchall()
    return jsonify(submissions=[{
        "task": r["task_ref"], "status": r["status"],
        "submittedAt": r["submitted_at"].isoformat() if r["submitted_at"] else None} for r in rows])


@app.get("/api/admin/students/<uuid:sid>/submissions/<ref>")
@api_user("admin")
def admin_submission(sid, ref):
    """The answers JSON stored in R2 for one student + task."""
    if not REF_RE.match(ref):
        return jsonify(error="bad_key"), 400
    with pool.connection() as conn:
        row = conn.execute("SELECT status FROM submission_status WHERE student_id = %s AND task_ref = %s",
                           (str(sid), ref)).fetchone()
    if not row or row["status"] != "YES":
        return jsonify(error="not_submitted"), 404
    try:
        data = store_get(sub_key(sid, ref))
    except Exception:
        app.logger.exception("storage read failed")
        return jsonify(error="storage_error"), 502
    if data is None:
        return jsonify(error="file_missing"), 404
    return Response(data, mimetype="application/json", headers={"Cache-Control": "no-store"})


@app.post("/api/admin/students/<uuid:sid>/submissions/<ref>/reopen")
@api_user("admin")
def admin_reopen(sid, ref):
    """Set status back to 'NO' so the student can retake. The old answers are archived in R2, not deleted."""
    if not REF_RE.match(ref):
        return jsonify(error="bad_key"), 400
    try:
        with pool.connection() as conn:
            row = conn.execute("UPDATE submission_status SET status = 'NO', submitted_at = NULL "
                               "WHERE student_id = %s AND task_ref = %s AND status = 'YES' RETURNING task_ref",
                               (str(sid), ref)).fetchone()
            if not row:
                return jsonify(error="not_found"), 404
            old = store_get(sub_key(sid, ref))
            if old is not None:
                stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
                store_put(f"submissions/_archive/{sid}/{ref}-{stamp}.json", old)
    except Exception:
        app.logger.exception("reopen failed")
        return jsonify(error="storage_error"), 502
    return jsonify(ok=True)


# ---------------------------------------------------------------- admin content manager API
@app.get("/api/admin/content")
@api_user("admin")
def admin_list():
    try:
        files = sorted((f for f in store_list() if cms_listed(f["key"])), key=lambda f: f["key"])
    except Exception:
        app.logger.exception("storage list failed")
        return jsonify(error="storage_error"), 502
    return jsonify(files=files, backend="Cloudflare R2" if R2_OK else "local folder")


@app.get("/api/admin/content/<path:key>")
@api_user("admin")
def admin_read(key):
    if not valid_key(key) or not key.endswith(".json") or key.startswith(HIDDEN_PREFIXES):
        return jsonify(error="bad_key"), 400
    try:
        data = store_get(key)
    except Exception:
        app.logger.exception("storage read failed")
        return jsonify(error="storage_error"), 502
    if data is None:
        return jsonify(error="not_found"), 404
    return Response(data, mimetype="application/json")


@app.put("/api/admin/content/<path:key>")
@api_user("admin")
def admin_write(key):
    if not valid_key(key) or not key.endswith(".json") or key.startswith(HIDDEN_PREFIXES):
        return jsonify(error="bad_key"), 400
    raw = request.get_data()
    if len(raw) > MAX_JSON_BYTES:
        return jsonify(error="too_large"), 413
    try:
        json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, ValueError) as e:
        return jsonify(error="invalid_json", detail=str(e)), 400
    try:
        store_put(key, raw)
    except Exception:
        app.logger.exception("storage write failed")
        return jsonify(error="storage_error"), 502
    CACHE.pop(key, None)
    if key == STATE_KEY:
        STATE_CACHE[0] = 0.0
    return jsonify(ok=True)


# ---------------------------------------------------------------- pages and static files
@app.get("/")
def home():
    u = current_user()
    if u:                                   # the public home page is for visitors before login
        return redirect("/" + landing_for(u))
    return send_from_directory(PUBLIC_DIR, "index.html")


@app.get("/<path:name>")
def public_file(name):
    if name in LEGACY_PAGES:
        q = request.query_string.decode()
        return redirect("/" + LEGACY_PAGES[name] + ("?" + q if q else ""))
    if name in PAGES:
        need, u = PAGES[name], current_user()
        if name == "login.html" and u:
            return redirect("/" + landing_for(u))
        if need and not u:
            return redirect(f"/login.html?next={name}")
        if need == "admin" and u["role"] != "admin":
            abort(403)
        if need == "student" and u["role"] != "student":   # admins never see the quiz
            return redirect("/" + landing_for(u))
        return send_from_directory(PUBLIC_DIR, name)
    if re.fullmatch(r"[\w.-]+\.(css|js)", name):
        return send_from_directory(PUBLIC_DIR, name)
    abort(404)


if __name__ == "__main__":
    app.run(debug=True)
